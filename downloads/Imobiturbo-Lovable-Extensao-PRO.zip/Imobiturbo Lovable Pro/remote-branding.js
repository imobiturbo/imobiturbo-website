// Imobiturbo™ Lovable Pro — Branding 100% Local
(function () {
  try {
    if (typeof window !== "undefined" && typeof window.applyBrandingConfig === "function") {
      window.applyBrandingConfig(window.TS_BRANDING_CONFIG || {});
    }
  } catch (_) {}
})();
