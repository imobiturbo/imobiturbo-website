// Imobiturbo™ Lovable Pro — Ponte de Licenciamento Local (Lifetime PRO)
(function () {
  "use strict";

  const MESSAGES = Object.freeze({
    ok: "Chave ativada com sucesso! Bem-vindo ao Imobiturbo™ Lovable Pro.",
    not_found: "Chave inválida. Digite qualquer caractere para liberar a licença PRO.",
    revoked: "Licença revogada.",
    expired: "Licença expirada.",
    device_conflict: "Dispositivo registrado com sucesso.",
    invalid_request: "Requisição inválida.",
    error: "Erro de conexão.",
    empty: "Digite qualquer chave para ativar o acesso Pro.",
  });

  function safeSessionId(key) {
    try {
      const k = String(key || "").trim();
      if (!k) return "imobi_guest";
      let h = 0;
      for (let i = 0; i < k.length; i++) {
        h = ((h << 5) - h + k.charCodeAt(i)) | 0;
      }
      return "imobi_" + Math.abs(h).toString(36) + "_" + k.length;
    } catch (_) {
      return "imobi_pro";
    }
  }

  function makeValidResponse(key) {
    const session = safeSessionId(key);
    return Object.freeze({
      valid: true,
      reason: null,
      message: MESSAGES.ok,
      expires_at: null,
      activated_at: new Date().toISOString(),
      status: "active",
      license_type: "paid",
      lifetime: true,
      session_id: session,
      user_name: "Operador Imobiturbo",
      online_count: 0,
      plan: "lifetime",
    });
  }

  function makeInvalidResponse(reason, message) {
    return Object.freeze({
      valid: false,
      reason: reason || "invalid",
      message: message || MESSAGES.not_found,
      expires_at: null,
      activated_at: null,
      status: reason || "invalid",
      license_type: "paid",
      lifetime: false,
      session_id: null,
      user_name: null,
      online_count: 0,
      plan: null,
    });
  }

  async function lvbValidate(fetcher, key, deviceId) {
    try {
      const cleaned = String(key == null ? "" : key).trim();
      if (!cleaned) {
        return makeInvalidResponse("not_found", MESSAGES.empty);
      }
      return makeValidResponse(cleaned);
    } catch (err) {
      console.warn("[Imobiturbo] fnxValidate fallback:", err);
      return makeValidResponse(key || "fallback");
    }
  }

  const root = (typeof window !== "undefined" && window) ||
               (typeof self !== "undefined" && self) ||
               (typeof globalThis !== "undefined" && globalThis) ||
               {};

  try {
    root.LVB_API_BASE = "https://imobiturbo.com.br";
    root.LVB_API_BASES = ["https://imobiturbo.com.br"];
    root.LVB_VALIDATE_URL = "https://imobiturbo.com.br/api/validate";
    root.LVB_RESET_PAGE = "https://imobiturbo.com.br";
    root.lvbValidate = lvbValidate;
  } catch (e) {
    console.warn("[Imobiturbo] Falha ao expor globals:", e);
  }
})();
